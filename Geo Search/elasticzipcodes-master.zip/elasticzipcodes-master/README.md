This is the data file for zipcodes in China.
The main purpose of this file is for elasticseach map demo
